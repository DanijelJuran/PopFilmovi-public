﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PopFilmovi.Data;
using PopFilmovi.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
namespace PopFilmovi.Controllers
{
    public class GetFilmoviPopController : Controller
    {
        // GET: Home
        public ActionResult GetFilmPopular()
        {

            var context = new DbfilmoviContext().Procedures;
            //DbfilmoviContextProcedures entities = new();
            var rez = context.GetFilmPopularAsync("", null, null);

            return View(rez.Result.ToList().Take(100));
        }
        [HttpPost]
        public async Task<IActionResult>  GetFilmPopular(string opis, DateTime? datumOd, DateTime? datumDo)
        {
            var context = new DbfilmoviContext().Procedures;
            //DbfilmoviContextProcedures entities = new();
            var rez = context.GetFilmPopularAsync(opis, datumOd, datumDo);
            if (rez == null)
            {
                return NotFound();
            }
            return View(rez.Result.ToList());
        }

       
        public async Task<IActionResult> GetFilmPopularID(int id)
        {   
           
            var context = new DbfilmoviContext().Procedures;
            
            var  film =  context.GetFilmPopularByIDAsync(id);
            if (film == null)
            {
                return NotFound();
            }
            return View(film.Result.ToList());
           
        }


    }
}
