﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using Newtonsoft.Json;
using PopFilmovi.Data;
using PopFilmovi.Models;

namespace PopFilmovi.Controllers
{
    public class UcitavanjeAPIController :Controller
    {
        private readonly IHttpClientFactory _clientFactory;
        public IEnumerable<Zanr> Zanrovi { get; set; }
        int maxPage = 150;
        const string BASE_URL_Zanr = @"https://api.themoviedb.org/3/genre/movie/list?api_key=e7d5c680221835e8a6c78a7c8e40a68e&language=en-US";
        string BASE_URL_FilmOrig = @"https://api.themoviedb.org/3/discover/movie?api_key=e7d5c680221835e8a6c78a7c8e40a68e&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page={0xx}&with_watch_monetization_types=flatrate";
        string BASE_URL_Film = "";
        public UcitavanjeAPIController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<IActionResult> UcitajZanrove()
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BASE_URL_Zanr))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();


                    var root = JsonConvert.DeserializeObject<RootObject>(apiResponse);

                    foreach (var p in root.genres)
                    {
                        var context = new DbfilmoviContext().Procedures;
                        OutputParameter<int> _izlaz = null;
                        //Console.WriteLine(p.Id + " " + p.name);
                        try {
                            _ = context.SetZanrItemAsync(int.Parse(p.Id.ToString()), p.name, _izlaz);
                        }
                        catch {
                            _izlaz = null;  
                            System.Exception e = new Exception();
                            Console.WriteLine(e.Message.ToString());
                        }


                    }
                }
            }
            return View();
        }

        public async Task<IActionResult> UcitajFilmove()
        {
            using (var httpClient = new HttpClient())
            {
                for (int i = 1; i <= maxPage; i++)
                {
                    BASE_URL_Film = BASE_URL_FilmOrig.Replace("{0xx}", i.ToString());
                    using (var response = await httpClient.GetAsync(BASE_URL_Film))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();


                        var root = JsonConvert.DeserializeObject<RootObjectFilmovi>(apiResponse);

                        foreach (var p in root.results)
                        {
                            var context = new DbfilmoviContext().Procedures;
                            OutputParameter<int> _izlaz = null;
                            Console.WriteLine(p.id + " " + p.original_title);

                            try
                            {
                               // DateTime? relaseDate = null;
                                
                                if (p.release_date==null)
                                { 
                                    Console.WriteLine("Krivo"); 
                                }


                                _ = context.SetFilmPopularAsync(int.Parse(p.id.ToString()),p.original_title, p.overview, string.Join(",", p.genre_ids), p.popularity, p.vote_average, p.release_date,_izlaz);
                            }
                            catch
                            {
                                _izlaz = null;
                                System.Exception e = new Exception();
                                Console.WriteLine(e.Message.ToString());
                            }


                        }
                    }
                }
            }
            return View();
        }


    }
}
