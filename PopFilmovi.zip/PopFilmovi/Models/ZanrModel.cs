﻿using System.ComponentModel.DataAnnotations;

namespace PopFilmovi.Models
{

 

    public class Genres
    {
        public int Id { get; set; }
        public string name { get; set; }
    }

    public class RootObject
    {
        public List<Genres> genres { get; set; }
    }
}
