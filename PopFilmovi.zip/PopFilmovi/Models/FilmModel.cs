﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PopFilmovi.Models
{
    public class Results
    {   [Key]
        public int id { get; set; }
        //public object Id { get; internal set; }
        public string[] genre_ids { get; set; }
        public string original_title { get; set; }
        public string overview { get; set; }
        public decimal popularity { get; set; }
        public DateTime? release_date { get; set; }
        public decimal vote_average { get; set; }
    }

    public class RootObjectFilmovi
    {
        public List<Results> results { get; set; }
    }
}
